﻿using MTG.Interfaces;
using MTG.Model.Objects;
using System;

namespace $rootnamespace$
{
    public class $safeitemname$: IPendingDamageResolution
    {
        #region Properties
        public Guid ActionPlayerId { get; set; }
        public int Damage { get; set; }
        public Guid Id { get; private set; }
        public Card OriginCard { get; set; }
        #endregion

        #region Constructors
        public $safeitemname$()
        {
            Id = Guid.NewGuid();
        }
        #endregion
    }
}
