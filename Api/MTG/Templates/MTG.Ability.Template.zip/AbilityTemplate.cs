﻿using MTG.Interfaces;
using MTG.ArgumentDefintions;
using MTG.Enumerations;
using System;
using System.Collections.Generic;

namespace $rootnamespace$
{ 
    public class $safeitemname$ : IAbility
    {
        /*
        * https://mtg.gamepedia.com/$safeitemname$
             
        */
        #region Events
        public event EventHandler OnPendingActionTriggered, OnEffectTriggered, OnEffectTrigger;
        #endregion

        #region Properties
        public EffectTrigger Trigger { get { return EffectTrigger.; } }
                public AbilityType Type { get { return AbilityType.; } }
                #endregion

        #region Constructors
        public $safeitemname$()
        {
            
        }
        #endregion

        #region Methods
        public void Process(AbilityArgs args)
        {
            throw new NotImplementedException("$safeitemname$.Process");
        }
        public override string ToString()
        {
            return this.GetType().Name;
        }
        #endregion
    }
}
