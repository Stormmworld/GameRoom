﻿using MTG.Interfaces;
using System;

namespace $rootnamespace$
{
    public class $safeitemname$: IPendingAction
    {
        #region Properties
        public Guid ActionPlayerId { get; set; }
        public Guid Id { get; private set; }
        #endregion

        #region Constructors
        public $safeitemname$()
        {
            Id = Guid.NewGuid();
        }
        #endregion
    }
}
