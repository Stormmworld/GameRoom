﻿using MTG.Interfaces;
using MTG.Enumerations;
using System;
using MTG.Model.Objects;

namespace $rootnamespace$
{
    public class $safeitemname$ : ITriggeredAbility
    {
        /*
        * $safeitemname$
        */
        #region Events
        public event EventHandler OnPendingActionTriggered, OnEffectTriggered, OnEffectTrigger;
        #endregion

        #region Properties
        public Guid Id { get; private set; }
        public EffectTrigger Trigger { get { return EffectTrigger.Card_Blocked; } }
        #endregion

        #region Constructors
        public $safeitemname$()
        {
            Id = Guid.NewGuid();
        }
        #endregion

        #region Methods
        public void Process(ITriggeredAbilityArgs args)
        {
            throw new NotImplementedException("$safeitemname$.Process");
        }
        public ITriggeredAbilityArgs GenerateArgs(ITriggeredAbilityArgs triggeredAbilityArgs, Card originCard)
        {
            throw new NotImplementedException("$safeitemname$.GenerateArgs");
        }
        public override string ToString()
        {
            return this.GetType().Name;
        }
        #endregion
    }
}