﻿using MTG.Interfaces;
using System.Collections.Generic;

namespace $rootnamespace$
{
    /*
     *  
     
     */
    public class $safeitemname$: IZone
    {
        #region Properties
        public List<Card> Cards { get; set; }
        #endregion
    }
}
