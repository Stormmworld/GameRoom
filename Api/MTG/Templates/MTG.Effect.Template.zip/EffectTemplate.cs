﻿using MTG.Enumerations;
using MTG.Interfaces;
using MTG.Model.Objects;

namespace $rootnamespace$
{
    public class $safeitemname$ : IEffect
    {
        /*
         * $safeitemname$
         */
        #region Properties
        public EffectTypes Type { get; private set; }
        public GamePhases EndingPhase { get; private set; }
        public Target Target { get; private set; }
        public int Value { get; private set; }
        #endregion

        #region Constructors
        public $safeitemname$()
        {
        }
        #endregion
    }
}
